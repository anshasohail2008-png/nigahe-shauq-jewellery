import { useState } from 'react';
import { Link } from 'react-router-dom';
import { User, Package, Heart, MapPin, Settings, LogOut, Mail, UserPlus, ShoppingBag } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useWishlist } from '@/context/WishlistContext';
import { useToast } from '@/context/ToastContext';
import { products } from '@/data/products';
import { formatPrice } from '@/lib/utils';
import { Breadcrumbs } from '@/components/ui/Breadcrumbs';
import { Badge } from '@/components/ui/Badge';
import { Input } from '@/components/ui/Form';
import { Button, LinkButton } from '@/components/ui/Button';

type Tab = 'profile' | 'orders' | 'wishlist' | 'addresses' | 'settings';
type AuthMode = 'signin' | 'signup';

export function AccountPage() {
  const { user, loading, signIn, signUp, signOut } = useAuth();
  const { showToast } = useToast();
  const { items: wishlistItems } = useWishlist();
  const wishlistProducts = wishlistItems.map((i) => products.find((p) => p.id === i.productId)).filter((p): p is NonNullable<typeof p> => !!p);

  const [tab, setTab] = useState<Tab>('profile');
  const [authMode, setAuthMode] = useState<AuthMode>('signin');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitting, setSubmitting] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (!email.trim()) err.email = 'Required';
    else if (!/\S+@\S+\.\S+/.test(email)) err.email = 'Invalid email';
    if (!password.trim()) err.password = 'Required';
    else if (password.length < 6) err.password = 'At least 6 characters';
    setErrors(err);
    if (Object.keys(err).length > 0) return;

    setSubmitting(true);
    const result = authMode === 'signin' ? await signIn(email, password) : await signUp(email, password);
    setSubmitting(false);

    if (result.error) {
      setErrors({ form: result.error });
    } else {
      showToast(authMode === 'signin' ? 'Welcome back.' : 'Account created successfully.');
      setEmail('');
      setPassword('');
      setErrors({});
    }
  };

  const handleSignOut = async () => {
    await signOut();
    showToast('You have been signed out.');
    setTab('profile');
  };

  // Loading state
  if (loading) {
    return (
      <div className="container-lux py-8">
        <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Account' }]} />
        <div className="flex items-center justify-center py-32">
          <div className="w-8 h-8 border-2 border-charcoal-200 dark:border-charcoal-700 border-t-champagne-400 rounded-full animate-spin" />
        </div>
      </div>
    );
  }

  // Logged-out state
  if (!user) {
    return (
      <div className="container-lux py-8">
        <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Account' }]} />
        <div className="max-w-md mx-auto mt-8">
          <div className="bg-warmwhite dark:bg-charcoal-800 p-8 lg:p-10">
            <div className="text-center mb-8">
              <div className="w-14 h-14 rounded-full bg-champagne-100 dark:bg-charcoal-700 flex items-center justify-center mx-auto mb-4">
                <User className="w-7 h-7 text-champagne-500" />
              </div>
              <h1 className="font-serif text-2xl text-charcoal-800 dark:text-ivory mb-2">
                {authMode === 'signin' ? 'Welcome Back' : 'Create Account'}
              </h1>
              <p className="text-sm text-charcoal-500 dark:text-charcoal-400">
                {authMode === 'signin'
                  ? 'Sign in to view your orders, wishlist, and saved addresses.'
                  : 'Join NIGAHE SHAUQ to track orders and save your favourites.'}
              </p>
            </div>

            <form onSubmit={handleAuth} className="space-y-4">
              <div>
                <Input
                  label="Email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  error={errors.email}
                  placeholder="you@example.com"
                  autoComplete="email"
                />
              </div>
              <div>
                <Input
                  label="Password"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  error={errors.password}
                  placeholder="At least 6 characters"
                  autoComplete={authMode === 'signin' ? 'current-password' : 'new-password'}
                />
              </div>
              {errors.form && (
                <p className="text-sm text-rose-500 bg-rose-50 dark:bg-rose-900/20 px-4 py-3">{errors.form}</p>
              )}
              <Button type="submit" size="lg" className="w-full" disabled={submitting}>
                {submitting ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-current border-t-transparent rounded-full animate-spin" />
                    Please wait
                  </span>
                ) : authMode === 'signin' ? (
                  <><Mail className="w-4 h-4" /> Sign In</>
                ) : (
                  <><UserPlus className="w-4 h-4" /> Create Account</>
                )}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <button
                onClick={() => {
                  setAuthMode(authMode === 'signin' ? 'signup' : 'signin');
                  setErrors({});
                }}
                className="text-sm text-charcoal-500 dark:text-charcoal-400 hover:text-champagne-500 transition-colors"
              >
                {authMode === 'signin'
                  ? "Don't have an account? Create one"
                  : 'Already have an account? Sign in'}
              </button>
            </div>
          </div>

          <div className="mt-6 text-center">
            <p className="text-xs text-charcoal-400">
              Want to track an order without signing in?{' '}
              <Link to="/track-order" className="text-champagne-500 hover:underline">Track your order here</Link>
            </p>
          </div>
        </div>
      </div>
    );
  }

  // Logged-in state
  const tabs: { key: Tab; label: string; icon: typeof User }[] = [
    { key: 'profile', label: 'Profile', icon: User },
    { key: 'orders', label: 'Orders', icon: Package },
    { key: 'wishlist', label: 'Wishlist', icon: Heart },
    { key: 'addresses', label: 'Addresses', icon: MapPin },
    { key: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="container-lux py-8">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Account' }]} />
      <h1 className="font-serif text-headline text-charcoal-800 dark:text-ivory mt-6 mb-8">My Account</h1>

      <div className="grid lg:grid-cols-4 gap-8">
        {/* Sidebar */}
        <aside className="lg:col-span-1">
          <div className="lg:sticky lg:top-28">
            <div className="bg-warmwhite dark:bg-charcoal-800 p-5 mb-4">
              <div className="w-14 h-14 rounded-full bg-champagne-200 dark:bg-champagne-700 flex items-center justify-center font-serif text-xl text-charcoal-700 dark:text-ivory mb-3">
                {(user.email ?? '?').charAt(0).toUpperCase()}
              </div>
              <p className="font-medium text-charcoal-800 dark:text-ivory break-all">{user.email}</p>
            </div>
            <nav className="space-y-1">
              {tabs.map((t) => (
                <button
                  key={t.key}
                  onClick={() => setTab(t.key)}
                  className={`flex items-center gap-3 w-full px-4 py-3 text-sm transition-colors ${
                    tab === t.key
                      ? 'bg-charcoal-800 text-ivory dark:bg-champagne-300 dark:text-charcoal-900'
                      : 'text-charcoal-600 dark:text-charcoal-300 hover:bg-beige-50 dark:hover:bg-charcoal-800'
                  }`}
                >
                  <t.icon className="w-4 h-4" /> {t.label}
                  {t.key === 'wishlist' && wishlistProducts.length > 0 && (
                    <span className="ml-auto text-xs opacity-70">{wishlistProducts.length}</span>
                  )}
                </button>
              ))}
              <button onClick={handleSignOut} className="flex items-center gap-3 w-full px-4 py-3 text-sm text-charcoal-500 hover:text-rose-500 transition-colors">
                <LogOut className="w-4 h-4" /> Sign Out
              </button>
            </nav>
          </div>
        </aside>

        {/* Content */}
        <div className="lg:col-span-3">
          {tab === 'profile' && (
            <div className="bg-warmwhite dark:bg-charcoal-800 p-6 lg:p-8">
              <h2 className="font-serif text-xl text-charcoal-800 dark:text-ivory mb-6">Profile Information</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <Input label="Email" defaultValue={user.email ?? ''} disabled />
              </div>
              <p className="mt-4 text-xs text-charcoal-400">
                Your account is linked to your email address. Additional profile fields can be added after your first order.
              </p>
            </div>
          )}

          {tab === 'orders' && (
            <div>
              <h2 className="font-serif text-xl text-charcoal-800 dark:text-ivory mb-6">Order History</h2>
              <div className="bg-warmwhite dark:bg-charcoal-800 p-12 text-center">
                <ShoppingBag className="w-10 h-10 text-charcoal-300 dark:text-charcoal-600 mx-auto mb-3" />
                <p className="text-charcoal-500 mb-4">No orders yet. When you place an order, it will appear here.</p>
                <LinkButton to="/shop" variant="outline">Browse Shop</LinkButton>
              </div>
            </div>
          )}

          {tab === 'wishlist' && (
            <div>
              <h2 className="font-serif text-xl text-charcoal-800 dark:text-ivory mb-6">Saved Items</h2>
              {wishlistProducts.length === 0 ? (
                <div className="bg-warmwhite dark:bg-charcoal-800 p-12 text-center">
                  <Heart className="w-10 h-10 text-charcoal-300 dark:text-charcoal-600 mx-auto mb-3" />
                  <p className="text-charcoal-500 mb-4">No saved items yet.</p>
                  <Link to="/shop" className="text-xs uppercase tracking-wider text-champagne-500 dark:text-champagne-300 hover:underline">Browse Shop</Link>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 gap-4">
                  {wishlistProducts.map((p) => (
                    <Link key={p.id} to={`/product/${p.slug}`} className="flex gap-4 bg-warmwhite dark:bg-charcoal-800 p-4 hover:shadow-sm transition-shadow">
                      <img src={p.images[0]} alt={p.name} className="w-16 h-20 object-cover" />
                      <div>
                        <p className="font-serif text-sm text-charcoal-800 dark:text-ivory">{p.name}</p>
                        <p className="text-xs text-charcoal-400">{formatPrice(p.salePrice ?? p.price)}</p>
                        {!p.inStock && <Badge variant="out" className="mt-1">Sold Out</Badge>}
                      </div>
                    </Link>
                  ))}
                </div>
              )}
            </div>
          )}

          {tab === 'addresses' && (
            <div>
              <h2 className="font-serif text-xl text-charcoal-800 dark:text-ivory mb-6">Saved Addresses</h2>
              <div className="bg-warmwhite dark:bg-charcoal-800 p-12 text-center">
                <MapPin className="w-10 h-10 text-charcoal-300 dark:text-charcoal-600 mx-auto mb-3" />
                <p className="text-charcoal-500 mb-4">No saved addresses yet. Addresses from your orders will be saved here automatically.</p>
                <LinkButton to="/shop" variant="outline">Start Shopping</LinkButton>
              </div>
            </div>
          )}

          {tab === 'settings' && (
            <div className="bg-warmwhite dark:bg-charcoal-800 p-6 lg:p-8">
              <h2 className="font-serif text-xl text-charcoal-800 dark:text-ivory mb-6">Settings</h2>
              <div className="space-y-5">
                {[
                  { label: 'Email notifications', desc: 'Receive updates about new arrivals and sales' },
                  { label: 'SMS notifications', desc: 'Order updates via text message' },
                  { label: 'Marketing emails', desc: 'Promotional content and newsletters' },
                ].map((s) => (
                  <label key={s.label} className="flex items-center justify-between py-3 border-b border-charcoal-100 dark:border-charcoal-700">
                    <div>
                      <p className="text-sm font-medium text-charcoal-800 dark:text-ivory">{s.label}</p>
                      <p className="text-xs text-charcoal-400">{s.desc}</p>
                    </div>
                    <input type="checkbox" defaultChecked className="w-10 h-6 accent-champagne-500" />
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
